#import the openCV library for image processing + numpy libraray for mathematical + matrix operations
import cv2
import numpy as np
import math
import time		#efficiency checking


#equirectangular to planar formula

#x=lo-lo1*cos(la1)            lo= longitude lo1=prime meridian
#y=la-la1					  la= latitude 	la1=equator


input_image="PANO_4.jpg"
input_logo="techsansar_logo.png"
output_image="PANO_4_logo.jpg"



#scale_factor = relative size of the logo wih respect to the 360 image size
scale_factor=0.2

def equirectangular_forward(image):
	width=image.shape[1]
	height=image.shape[0]
	
	image_360 = np.zeros((height,width*2+1,4), np.uint8)
	
	for i in range(height):
		for j in range(width):
				x,y=j-width/2,i-height/2
				
				r=math.hypot(x,y)
				theta=math.atan2(x,y)
				
				image_360[r,theta*height/math.pi+height]=image[i,j] 
	
	kernel = np.ones((3,3),np.uint8)
	closing = cv2.morphologyEx(image_360, cv2.MORPH_CLOSE, kernel)
				
	return closing


def equirectangular_reverse(image):
	width=image.shape[1]
	height=image.shape[0]
	
	image_360 = np.zeros((height,width*2+1,4), np.uint8)
	
	for i in range(height):
		for j in range(width*2+1):
			
				r=i;
				theta=(j-height)*math.pi/height
				
				x=round(r*math.cos(theta)+height/2)
				y=round(r*math.sin(theta)+width/2)
				
				if(x in range(height) and y in range(width)):
					image_360[i,j]=image[x,y] 
				
	return image_360

	
	
def make_square(image):
	height=image.shape[0]
	width=image.shape[1]
	if(height==width):
		return image
		
	if(width>height):
		square_image = cv2.copyMakeBorder(image,(width-height)//2,(width-height)//2,0,0,cv2.BORDER_CONSTANT)
	else:
		square_image = cv2.copyMakeBorder(image,0,0,(height-width)//2,(height-width)//2,cv2.BORDER_CONSTANT)
	
	return square_image
		

image_pano=cv2.imread(input_image)	#read 360 image
#height and width of the 360 image file 
width=image_pano.shape[1]		
height=image_pano.shape[0]


image_logo=cv2.imread(input_logo,cv2.IMREAD_UNCHANGED)	#read logo image
image_logo_square=make_square(image_logo)

before=time.time()

image_logo_360=equirectangular_reverse(image_logo_square)

#resize logo size to fit the 360 image size
image_logo_360=cv2.resize(image_logo_360,(width,int(height*scale_factor)), interpolation = cv2.INTER_LINEAR)

print(time.time()-before)

#cv2.imshow('image_logo_360',image_pano[200:201])
#cv2.imshow('new_image',cv2.resize(image_pano[200:201],(50,1))) 



#overlapping the logo image into the 360 image

for i in range(int(height*scale_factor)):
	for j in range(width):
		if(image_logo_360[i,j,3]):	#if alpha>0, overwrite with logo image
			i_new=i#+int(height*(1.0-scale_factor))
			image_pano[i_new,j] = image_logo_360[i,j,:3]



cv2.imwrite(output_image,image_pano)	#image saving







