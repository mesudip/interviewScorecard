import cv2
import numpy as np
import math
import time

def make_square(image):
	height=image.shape[0]
	width=image.shape[1]
	if(height==width):
		return image
		
	if(width>height):
		square_image = cv2.copyMakeBorder(image,(width-height)//2,(width-height)//2,0,0,cv2.BORDER_CONSTANT)
	else:
		square_image = cv2.copyMakeBorder(image,0,0,(height-width)//2,(height-width)//2,cv2.BORDER_CONSTANT)
	
	return square_image
		


image_logo=cv2.imread('test.png',cv2.IMREAD_UNCHANGED)	#read logo image

square_image_logo=make_square(image_logo)

cv2.imwrite('squared_logo.jpg',square_image_logo)
cv2.imshow('final_image',square_image_logo)
cv2.waitKey(0)
