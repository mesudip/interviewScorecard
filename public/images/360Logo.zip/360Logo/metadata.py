from libxmp import XMPFiles, consts
import libxmp
import cv2



original_image="venice_360.jpg"
image_with_logo="PANO_4_logo.jpg"

template_image="PANO_4.jpg"



image=cv2.imread(image_with_logo)
width=image.shape[1]		
height=image.shape[0]

xmpfile = XMPFiles( file_path=original_image, open_forupdate=True )
xmptempfile=XMPFiles(file_path=template_image,open_fordpdate=True)
xmp = xmpfile.get_xmp()

xmpfile2 = XMPFiles( file_path=image_with_logo, open_forupdate=True )
xmp2 = xmpfile.get_xmp()

#metadata required for a 360 panorama image

#<GPano:ProjectionType>equirectangular</GPano:ProjectionType>
   #<GPano:UsePanoramaViewer>True</GPano:UsePanoramaViewer>
   #<GPano:CroppedAreaImageWidthPixels>8000</GPano:CroppedAreaImageWidthPixels>
   #<GPano:CroppedAreaImageHeightPixels>4000</GPano:CroppedAreaImageHeightPixels>
   #<GPano:FullPanoWidthPixels>8000</GPano:FullPanoWidthPixels>
   #<GPano:FullPanoHeightPixels>4000</GPano:FullPanoHeightPixels>
   #<GPano:CroppedAreaLeftPixels>0</GPano:CroppedAreaLeftPixels>
   #<GPano:CroppedAreaTopPixels>0</GPano:CroppedAreaTopPixels>
   #<GPano:StitchingSoftware>NadirPatch 1.2 (www.nadirpatch.com)</GPano:StitchingSoftware>
try:

    xmp.set_property(consts.XMP_NS_GPANO, u'ProjectionType', u'equirectangular' )
    xmp.set_property(consts.XMP_NS_GPANO, u'UsePanoramaViewer', u'True' )
    xmp.set_property(consts.XMP_NS_GPANO, u'CroppedAreaImageWidthPixels',str(width) )
    xmp.set_property(consts.XMP_NS_GPANO, u'CroppedAreaImageHeightPixels',str(height) )
    xmp.set_property(consts.XMP_NS_GPANO, u'FullPanoWidthPixels',str(width) )
    xmp.set_property(consts.XMP_NS_GPANO, u'FullPanoHeightPixels',str(height) )
    xmp.set_property(consts.XMP_NS_GPANO, u'CroppedAreaLeftPixels',u'0')
    xmp.set_property(consts.XMP_NS_GPANO, u'CroppedAreaTopPixels',u'0')
    xmp.set_property(consts.XMP_NS_GPANO, u'StitchingSoftware',u'neonrender.com')
except libxmp.XMPError:
    xmp = xmptempfile.get_xmp()
    xmp.set_property(consts.XMP_NS_GPANO, u'ProjectionType', u'equirectangular' )
    xmp.set_property(consts.XMP_NS_GPANO, u'UsePanoramaViewer', u'True' )
    xmp.set_property(consts.XMP_NS_GPANO, u'CroppedAreaImageWidthPixels',str(width) )
    xmp.set_property(consts.XMP_NS_GPANO, u'CroppedAreaImageHeightPixels',str(height) )
    xmp.set_property(consts.XMP_NS_GPANO, u'FullPanoWidthPixels',str(width) )
    xmp.set_property(consts.XMP_NS_GPANO, u'FullPanoHeightPixels',str(height) )
    xmp.set_property(consts.XMP_NS_GPANO, u'CroppedAreaLeftPixels',u'0')
    xmp.set_property(consts.XMP_NS_GPANO, u'CroppedAreaTopPixels',u'0')
    xmp.set_property(consts.XMP_NS_GPANO, u'StitchingSoftware',u'neonrender.com')
    pass
#saving the xmp data into the file 


xmpfile2.put_xmp(xmp)
xmpfile2.close_file()

