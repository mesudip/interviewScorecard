import cv2
import numpy as np

jpg_filename="techsansar_logo.jpg"
png_filename="techsansar_logo.png"

image_jpg=cv2.imread(jpg_filename,cv2.IMREAD_UNCHANGED)

row=image_jpg.shape[0]
column=image_jpg.shape[1]


image_png=np.zeros([row,column,4],dtype=image_jpg.dtype)

for i in range(len(image_jpg)):
    for j in range(len(image_jpg[i])):
        image_png[i,j]=[image_jpg[i,j,0],image_jpg[i,j,1],image_jpg[i,j,2],255]


cv2.imwrite(png_filename, image_png)