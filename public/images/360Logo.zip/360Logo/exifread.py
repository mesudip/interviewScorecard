
import exifread
# Open image file for reading (binary mode)
f = open('venice_360.jpg', 'rb')


dir(exifread)
# Return Exif tags
#tags = exifread.process_file(f)
